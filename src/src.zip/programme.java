import java.awt.CardLayout;

import javax.swing.JFrame;
import javax.swing.JTextArea;


public class programme extends JFrame
{
	Feed feed;
	public programme()
	{
		super("Nothing");
		//MovieClass movieClass = new MovieClass();
		//BangladeshiNews bangladeshiNews = new BangladeshiNews();
		//Enterpreuner enterpreuner = new Enterpreuner();
		RSSFeedParser parser = new RSSFeedParser("http://www.bangladesh.com/blog/rss/");
		parser.readFeed();
	}
}
