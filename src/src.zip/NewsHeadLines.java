
public class NewsHeadLines
{
    RSSFeedParser parser = new RSSFeedParser("http://www.forbes.com/real-time/feed2/");
	
	Feed feed = parser.readFeed();
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		System.out.println(message);
	}
	}
}
