
public class SportsNewsClass {
	
    RSSFeedParser parser = new RSSFeedParser("http://sports.espn.go.com/espn/rss/news");
	
	Feed feed = parser.readFeed();
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		System.out.println(message);
	}
	}

}
