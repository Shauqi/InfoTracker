
public class ScienceNews
{
	
    RSSFeedParser parser = new RSSFeedParser("http://www.wired.com/category/science/feed/");
	
	Feed feed = parser.readFeed();
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		System.out.println(message);
	}
	}

}
