
public class HollywoodCelebrityNews 
{
    RSSFeedParser parser = new RSSFeedParser("http://www.popeater.com/rss.xml"/*"http://www.tmz.com/rss.xml"*/);
	
	Feed feed = parser.readFeed();
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		System.out.println(message);
	}
	}
}
