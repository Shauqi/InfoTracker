
public class IslamicViews
{	
    RSSFeedParser parser = new RSSFeedParser("http://www.salaattime.com/feed/");
	
	Feed feed = parser.readFeed();
	String data = "";
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		System.out.println(message);
		data+=message+"\n";
	}
	}
	
	String getData()
	{
		return data;
	}
}
