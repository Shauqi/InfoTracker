import javax.swing.JFrame;
import javax.swing.JPanel;

public class ReadTest {

	public static void main(String[] args) 
	{
		programme p = new programme();
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p.setSize(250,250);
		p.setVisible(true);
		//IslamicViews islamicViews = new IslamicViews();
		//MovieClass movies = new MovieClass();
		//NewsHeadLines news = new NewsHeadLines();
		//Enterpreuner enterpreuner = new Enterpreuner();
		//TechNews techNews = new TechNews();
		//BangladeshiNews bangladeshiNews = new BangladeshiNews();
		//HollywoodCelebrityNews hollywoodCelebrityNews = new HollywoodCelebrityNews();
	}

}
