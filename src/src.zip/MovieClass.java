import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class MovieClass
{
	String data = "";
    
	MovieFeedParser parser = new MovieFeedParser("http://www.fandango.com/rss/top10boxoffice.rss");
	
	MovieFeed movieFeed = parser.readFeed();
	public MovieClass()
	{
		
	for(MovieFeedMessage message : movieFeed.getMessages())
	{
		System.out.println(message);
		data+=message+"\n";
	}
	
	}
	public String getData()
	{
		return data;
	}
}
