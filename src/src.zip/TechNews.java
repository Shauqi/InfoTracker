
public class TechNews 
{
	 RSSFeedParser parser = new RSSFeedParser("http://www.forbes.com/technology/feed/");
		
		Feed feed = parser.readFeed();
		
		{
		for(FeedMessage message : feed.getMessages())
		{
			System.out.println(message);
		}
		}
}
