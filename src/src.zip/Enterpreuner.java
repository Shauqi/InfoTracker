
public class Enterpreuner 
{
    RSSFeedParser parser = new RSSFeedParser("http://www.forbes.com/entrepreneurs/feed/");
	
	Feed feed = parser.readFeed();
	String data = "";
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		data+=message+"\n";
	}
	}
	
	String getData()
	{
		return data;
	}
}
