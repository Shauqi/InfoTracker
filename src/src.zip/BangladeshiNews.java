
public class BangladeshiNews 
{
    RSSFeedParser parser = new RSSFeedParser("http://www.bangladesh.com/blog/rss/");
	
	Feed feed = parser.readFeed();
	
	String data="";
	
	{
	for(FeedMessage message : feed.getMessages())
	{
		data+=message+"\n";
	}
	}
	String getData()
	{
		return data;
	}
}
